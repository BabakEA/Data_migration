const AWS = require('aws-sdk')
const dms = new AWS.DMS();

exports.handler = async(event) => {

    const params = {
        CdcStartTime: process.env.DMS_TASK1_CDC_TIME,
        ReplicationTaskArn: process.env.DMS_TASK1_ARN,
        StartReplicationTaskType: "start-replication"
    };

    dms.startReplicationTask(params, function (err, data) {
        if (err) {
            console.log(err, err.stack);
            return err;
        }
        else {
            console.log(data);
            return data;
        }
    });
}
