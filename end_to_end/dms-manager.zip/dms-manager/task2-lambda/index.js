const AWS = require('aws-sdk')
const dms = new AWS.DMS();

const DMS_REPLICATION_TASK_STOP_EVENT_ID = 'DMS-EVENT-0079';

exports.handler = async(event) => {

    const message = event.Records[0].Sns.Message;
    console.log(message)
    const dmsEventIDStrings = message['Event ID'].split('#')
    const dmsEventID = dmsEventIDStrings[dmsEventIDStrings.length - 1].trim();

    if(dmsEventID === DMS_REPLICATION_TASK_STOP_EVENT_ID) {
        const params = {
            CdcStartTime: process.env.DMS_TASK2_CDC_TIME,
            ReplicationTaskArn: process.env.DMS_TASK2_ARN,
            StartReplicationTaskType: "start-replication"
        };

        dms.startReplicationTask(params, function (err, data) {
            if (err) {
                console.log(err, err.stack);
                return err;
            }
            else {
                console.log(data);
                return data;
            }
        });
    } else {
        return message;
    }
}

